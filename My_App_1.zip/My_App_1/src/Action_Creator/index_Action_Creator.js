import { Add, Remove, Remove_All } from "../types";

export const Add_Reminder = (text, date) => {
  const action = {
    type: Add,
    text,
    date,
  };
  return action;
};

export const Remove_Reminder = (id) => {
  const action = {
    type: Remove,
    id,
  };
  return action;
};

export const remove_All = (text, date) => {
  const action = {
    type: Remove_All,
  };
  return action;
};
