import React, { Component } from "react";
import moment from "moment";
import { connect } from "react-redux";
import { Add_Reminder } from "../Action_Creator/index_Action_Creator";
import { Remove_Reminder } from "../Action_Creator/index_Action_Creator";
import { remove_All } from "../Action_Creator/index_Action_Creator";

class App extends Component {
  state = {
    text: " ",
    date: new Date(),
  };
  render_Reminder = () => {
    const { reminders } = this.props;
    return (
      <ul className="list-style list-group">
        {reminders.map((reminder) => {
          return (
            <li key={reminder.id} className="list-group-item">
              <div>{reminder.text}</div>
              <div>
                {moment(new Date(reminder.date)).format(
                  "MMMM Do YYYY, h:mm:ss a"
                )}
              </div>
              <div
                className="Remove btn btn-danger"
                onClick={() => this.props.Remove_Reminder(reminder.id)}
              >
                x
              </div>
            </li>
          );
        })}
      </ul>
    );
  };

  Show_Date = () => {
    let date = moment(new Date()).format("MMMM Do YYYY, h:mm:ss a");
    return date;
  };
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-8 offset-2">
            <div className="App p-5 m-5">
              <div className="App-Title">
                <h2 className="header">Your To-Do Lists?</h2>
                <div className="time">{this.Show_Date()}</div>
              </div>
              <input
                className="input-one form-control"
                type="text"
                placeholder="Enter What U Think ?"
                onChange={(e) => this.setState({ text: e.target.value })}
              />
              <input
                className="form-control"
                type="datetime-local"
                onChange={(e) => this.setState({ date: e.target.value })}
              />
              {this.render_Reminder()}

              <button
                className="button-add btn btn-primary btn-block"
                onClick={() =>
                  this.props.Add_Reminder(this.state.text, this.state.date)
                }
              >
                Add Reminder
              </button>
              <button
                className="button-remove btn btn-danger btn-block"
                onClick={() => this.props.remove_All()}
              >
                Clear Reminder
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default connect(
  (state) => {
    return { reminders: state };
  },
  { Add_Reminder, Remove_Reminder, remove_All }
)(App);
