import { Add } from "../types";
import { Remove } from "../types";
import { Remove_All } from "../types";

// import { Add_Reminder } from "../Action_Creator/index_Action_Creator";
const Reminder = (state = [], action) => {
  let reminder = [];
  if (action.type === Add) {
    reminder = [
      ...state,
      { text: action.text, date: action.date, id: Math.random() * 999 },
    ];
    return reminder;
  } else if (action.type === Remove) {
    reminder = state.filter((reminder) => reminder.id !== action.id);
    return reminder;
  } else if (action.type === Remove_All) {
    return (reminder = []);
  } else {
    return state;
  }
};
export default Reminder;
