export const Add = "ADD_REMINDER";
export const Remove = "REMOVE_REMINDER";
export const Remove_All = " REMOVE_ALL";
